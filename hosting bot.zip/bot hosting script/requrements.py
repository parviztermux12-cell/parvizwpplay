aiogram==3.17.0
firebase-admin==6.5.0
aiofiles==23.2.1
python-dotenv==1.0.0
psutil==5.9.6
aiohttp==3.9.1