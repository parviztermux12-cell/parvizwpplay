import asyncio
import logging
import json
import sqlite3
from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command, CommandObject
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Загрузка конфигурации
def load_config():
    try:
        with open('config.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Ошибка загрузки конфига: {e}")
        return {}

config = load_config()
BOT_TOKEN = config.get('bot_token', 'YOUR_BOT_TOKEN_HERE')
ADMIN_IDS = config.get('admin_ids', [])
CURRENCY = config.get('currency', '₽')

# Инициализация бота
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# Инициализация БД
def init_db():
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    
    # Таблица пользователей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            balance REAL DEFAULT 0,
            reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Таблица тарифов
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tariffs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            duration_days INTEGER NOT NULL,
            features TEXT,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Таблица подписок
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            tariff_id INTEGER,
            start_date TIMESTAMP,
            end_date TIMESTAMP,
            is_active BOOLEAN DEFAULT TRUE,
            FOREIGN KEY (user_id) REFERENCES users (user_id),
            FOREIGN KEY (tariff_id) REFERENCES tariffs (id)
        )
    ''')
    
    # Таблица платежей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            amount REAL,
            payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'pending',
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        )
    ''')
    
    # Добавляем базовые тарифы если их нет
    cursor.execute("SELECT COUNT(*) FROM tariffs")
    if cursor.fetchone()[0] == 0:
        base_tariffs = [
            ("📊 Базовый", "Базовый доступ к контенту", 500, 30, "Доступ к базовому контенту|Поддержка 24/7"),
            ("🚀 Стандарт", "Расширенный доступ", 1000, 30, "Весь контент|Приоритетная поддержка|Эксклюзивные материалы"),
            ("👑 Премиум", "Полный доступ", 2000, 30, "Весь контент|Максимальная поддержка|Эксклюзивные материалы|Личный менеджер")
        ]
        
        for name, description, price, duration, features in base_tariffs:
            cursor.execute(
                "INSERT INTO tariffs (name, description, price, duration_days, features) VALUES (?, ?, ?, ?, ?)",
                (name, description, price, duration, features)
            )
    
    conn.commit()
    conn.close()

init_db()

# Состояния для админ-панели
class AdminStates(StatesGroup):
    waiting_tariff_name = State()
    waiting_tariff_description = State()
    waiting_tariff_price = State()
    waiting_tariff_duration = State()
    waiting_tariff_features = State()

# Клавиатуры
def get_main_keyboard():
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📋 Тарифы"), KeyboardButton(text="👤 Мои подписки")],
            [KeyboardButton(text="🏦 Кабинет"), KeyboardButton(text="👨‍💻 Админ-панель")]
        ],
        resize_keyboard=True
    )
    return keyboard

def get_admin_keyboard():
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📋 Управление тарифами"), KeyboardButton(text="👤 Управление пользователями")],
            [KeyboardButton(text="💳 Платежи"), KeyboardButton(text="📊 Статистика")],
            [KeyboardButton(text="⚙️ Настройки"), KeyboardButton(text="🔙 Назад")]
        ],
        resize_keyboard=True
    )
    return keyboard

def get_tariffs_keyboard():
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, price FROM tariffs WHERE is_active = TRUE")
    tariffs = cursor.fetchall()
    conn.close()
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[])
    
    for tariff_id, name, price in tariffs:
        keyboard.inline_keyboard.append([
            InlineKeyboardButton(text=f"{name} - {price}{CURRENCY}", callback_data=f"tariff_{tariff_id}")
        ])
    
    return keyboard

def get_cabinet_keyboard():
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="replenish_balance")],
        [InlineKeyboardButton(text="📋 История платежей", callback_data="payment_history")]
    ])
    return keyboard

# Вспомогательные функции
def get_user(user_id):
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    return user

def create_user(user_id, username, first_name):
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR IGNORE INTO users (user_id, username, first_name) VALUES (?, ?, ?)",
        (user_id, username, first_name)
    )
    conn.commit()
    conn.close()

def update_balance(user_id, amount):
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))
    conn.commit()
    
    cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
    new_balance = cursor.fetchone()[0]
    conn.close()
    
    return new_balance

def get_active_subscription(user_id):
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT s.id, t.name, t.description, s.start_date, s.end_date 
        FROM subscriptions s
        JOIN tariffs t ON s.tariff_id = t.id
        WHERE s.user_id = ? AND s.is_active = TRUE AND s.end_date > datetime('now')
    ''', (user_id,))
    subscription = cursor.fetchone()
    conn.close()
    return subscription

def get_tariffs_count():
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM tariffs WHERE is_active = TRUE")
    count = cursor.fetchone()[0]
    conn.close()
    return count

def get_active_subscriptions_count():
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM subscriptions WHERE is_active = TRUE AND end_date > datetime('now')")
    count = cursor.fetchone()[0]
    conn.close()
    return count

def get_total_revenue():
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(amount) FROM payments WHERE status = 'completed'")
    total = cursor.fetchone()[0] or 0
    conn.close()
    return total

# Обработчики команд
@dp.message(Command("start"))
async def start_command(message: types.Message):
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name
    
    create_user(user_id, username, first_name)
    
    welcome_text = config.get('welcome_text', 
        "👋 Добро пожаловать в сервис платных подписок!\n\n"
        "Здесь вы можете приобрести подписку на эксклюзивный контент и услуги.\n"
        "Используйте кнопки ниже для навигации:"
    )
    
    await message.answer(welcome_text, reply_markup=get_main_keyboard())

@dp.message(Command("admin"))
async def admin_command(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        await message.answer("❌ Доступ запрещен")
        return
    await message.answer("👨‍💻 Админ-панель", reply_markup=get_admin_keyboard())

@dp.message(F.text == "📋 Тарифы")
async def tariffs_handler(message: types.Message):
    tariffs_text = "📋 <b>Доступные тарифы</b>\n\nВыберите подходящий тариф:"
    await message.answer(tariffs_text, reply_markup=get_tariffs_keyboard(), parse_mode="HTML")

@dp.callback_query(F.data.startswith('tariff_'))
async def tariff_detail_handler(callback: types.CallbackQuery):
    tariff_id = int(callback.data.replace('tariff_', ''))
    
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    cursor.execute("SELECT name, description, price, duration_days, features FROM tariffs WHERE id = ?", (tariff_id,))
    tariff = cursor.fetchone()
    conn.close()
    
    if not tariff:
        await callback.answer("❌ Тариф не найден")
        return
    
    name, description, price, duration_days, features = tariff
    
    tariff_text = f"""<b>{name}</b>

💵 Стоимость: <b>{price}{CURRENCY}</b>
⏰ Срок действия: <b>{duration_days} дней</b>

📝 Описание:
{description}

✨ <b>Вы получите доступ к:</b>"""
    
    if features:
        for feature in features.split('|'):
            tariff_text += f"\n• {feature}"
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛒 Купить подписку", callback_data=f"buy_tariff_{tariff_id}")],
        [InlineKeyboardButton(text="🔙 Назад к тарифам", callback_data="back_to_tariffs")]
    ])
    
    await callback.message.edit_text(tariff_text, reply_markup=keyboard, parse_mode="HTML")
    await callback.answer()

@dp.callback_query(F.data.startswith('buy_tariff_'))
async def buy_tariff_handler(callback: types.CallbackQuery):
    tariff_id = int(callback.data.replace('buy_tariff_', ''))
    user_id = callback.from_user.id
    
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    
    # Получаем информацию о тарифе
    cursor.execute("SELECT name, price FROM tariffs WHERE id = ?", (tariff_id,))
    tariff = cursor.fetchone()
    
    if not tariff:
        await callback.answer("❌ Тариф не найден")
        return
    
    name, price = tariff
    
    # Проверяем баланс пользователя
    cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
    user_balance = cursor.fetchone()[0]
    
    if user_balance < price:
        await callback.answer("❌ Недостаточно средств на балансе")
        return
    
    # Проверяем активную подписку
    cursor.execute('''
        SELECT id FROM subscriptions 
        WHERE user_id = ? AND is_active = TRUE AND end_date > datetime('now')
    ''', (user_id,))
    active_sub = cursor.fetchone()
    
    if active_sub:
        await callback.answer("❌ У вас уже есть активная подписка")
        return
    
    # Создаем подписку
    start_date = datetime.now()
    end_date = start_date + timedelta(days=30)  # Базовый период
    
    cursor.execute(
        "INSERT INTO subscriptions (user_id, tariff_id, start_date, end_date) VALUES (?, ?, ?, ?)",
        (user_id, tariff_id, start_date, end_date)
    )
    
    # Списание средств
    cursor.execute("UPDATE users SET balance = balance - ? WHERE user_id = ?", (price, user_id))
    
    # Записываем платеж
    cursor.execute(
        "INSERT INTO payments (user_id, amount, status) VALUES (?, ?, 'completed')",
        (user_id, price)
    )
    
    conn.commit()
    conn.close()
    
    await callback.answer(f"✅ Подписка '{name}' успешно активирована!")
    await callback.message.answer(
        f"🎉 Поздравляем! Вы активировали подписку <b>{name}</b>\n"
        f"⏰ Действует до: {end_date.strftime('%d.%m.%Y %H:%M')}",
        parse_mode="HTML"
    )

@dp.message(F.text == "👤 Мои подписки")
async def my_subscriptions_handler(message: types.Message):
    user_id = message.from_user.id
    subscription = get_active_subscription(user_id)
    
    if subscription:
        sub_id, name, description, start_date, end_date = subscription
        start_date = datetime.fromisoformat(start_date)
        end_date = datetime.fromisoformat(end_date)
        
        days_left = (end_date - datetime.now()).days
        
        subscription_text = f"""👤 <b>Ваша активная подписка</b>

📋 Тариф: <b>{name}</b>
📅 Начало: {start_date.strftime('%d.%m.%Y')}
📅 Окончание: {end_date.strftime('%d.%m.%Y')}
⏰ Осталось дней: <b>{days_left}</b>

📝 Описание:
{description}"""
    else:
        subscription_text = """👤 <b>Мои подписки</b>

📋 Активные подписки отсутствуют.

💡 Чтобы приобрести подписку, нажмите кнопку «📋 Тарифы»"""
    
    await message.answer(subscription_text, parse_mode="HTML")

@dp.message(F.text == "🏦 Кабинет")
async def cabinet_handler(message: types.Message):
    user_id = message.from_user.id
    user = get_user(user_id)
    
    if not user:
        await message.answer("❌ Пользователь не найден")
        return
    
    user_id, username, first_name, balance, reg_date = user
    
    subscription = get_active_subscription(user_id)
    has_active_sub = "✅ Активна" if subscription else "❌ Отсутствует"
    
    cabinet_text = f"""🏦 <b>Кабинет</b>

🆔 Ваш ID: <code>{user_id}</code>
👤 Имя: {first_name}
💳 Баланс: <b>{balance}{CURRENCY}</b>
📋 Подписка: {has_active_sub}

💸 <b>Доступные действия:</b>"""
    
    await message.answer(cabinet_text, reply_markup=get_cabinet_keyboard(), parse_mode="HTML")

@dp.message(F.text == "👨‍💻 Админ-панель")
async def admin_panel_handler(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        await message.answer("❌ Доступ запрещен")
        return
    await message.answer("👨‍💻 Добро пожаловать в админ-панель!", reply_markup=get_admin_keyboard())

# Админ-обработчики
@dp.message(F.text == "📋 Управление тарифами")
async def admin_tariffs_handler(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Добавить тариф", callback_data="admin_add_tariff")],
        [InlineKeyboardButton(text="📋 Список тарифов", callback_data="admin_list_tariffs")],
        [InlineKeyboardButton(text="✏️ Редактировать тариф", callback_data="admin_edit_tariffs")]
    ])
    
    await message.answer("📋 Управление тарифами:", reply_markup=keyboard)

@dp.callback_query(F.data == "admin_add_tariff")
async def admin_add_tariff_handler(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    
    await state.set_state(AdminStates.waiting_tariff_name)
    await callback.message.answer("Введите название тарифа:")
    await callback.answer()

@dp.message(AdminStates.waiting_tariff_name)
async def process_tariff_name(message: types.Message, state: FSMContext):
    await state.update_data(name=message.text)
    await state.set_state(AdminStates.waiting_tariff_description)
    await message.answer("Введите описание тарифа:")

@dp.message(AdminStates.waiting_tariff_description)
async def process_tariff_description(message: types.Message, state: FSMContext):
    await state.update_data(description=message.text)
    await state.set_state(AdminStates.waiting_tariff_price)
    await message.answer("Введите цену тарифа:")

@dp.message(AdminStates.waiting_tariff_price)
async def process_tariff_price(message: types.Message, state: FSMContext):
    try:
        price = float(message.text)
        await state.update_data(price=price)
        await state.set_state(AdminStates.waiting_tariff_duration)
        await message.answer("Введите длительность тарифа в днях:")
    except ValueError:
        await message.answer("❌ Введите корректную цену (число):")

@dp.message(AdminStates.waiting_tariff_duration)
async def process_tariff_duration(message: types.Message, state: FSMContext):
    try:
        duration = int(message.text)
        await state.update_data(duration=duration)
        await state.set_state(AdminStates.waiting_tariff_features)
        await message.answer("Введите возможности тарифа через | (например: Доступ к контенту|Поддержка 24/7):")
    except ValueError:
        await message.answer("❌ Введите корректную длительность (целое число):")

@dp.message(AdminStates.waiting_tariff_features)
async def process_tariff_features(message: types.Message, state: FSMContext):
    data = await state.get_data()
    
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO tariffs (name, description, price, duration_days, features) VALUES (?, ?, ?, ?, ?)",
        (data['name'], data['description'], data['price'], data['duration'], message.text)
    )
    conn.commit()
    conn.close()
    
    await message.answer(f"✅ Тариф '{data['name']}' успешно добавлен!")
    await state.clear()

@dp.message(F.text == "📊 Статистика")
async def admin_stats_handler(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    
    tariffs_count = get_tariffs_count()
    active_subs = get_active_subscriptions_count()
    total_revenue = get_total_revenue()
    
    conn = sqlite3.connect('subscriptions.db')
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM users")
    users_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT SUM(amount) FROM payments WHERE status = 'completed' AND date(payment_date) = date('now')")
    today_revenue = cursor.fetchone()[0] or 0
    conn.close()
    
    stats_text = f"""📊 <b>Статистика подписок</b>

👥 Пользователей: {users_count}
📋 Тарифов: {tariffs_count}
👤 Активных подписок: {active_subs}
💰 Общая выручка: {total_revenue}{CURRENCY}
💰 Выручка за сегодня: {today_revenue}{CURRENCY}"""

    await message.answer(stats_text, parse_mode="HTML")

@dp.message(F.text == "🔙 Назад")
async def back_handler(message: types.Message):
    await message.answer("Главное меню:", reply_markup=get_main_keyboard())

@dp.callback_query(F.data == "back_to_tariffs")
async def back_to_tariffs_handler(callback: types.CallbackQuery):
    await callback.message.edit_text(
        "📋 <b>Доступные тарифы</b>\n\nВыберите подходящий тариф:",
        reply_markup=get_tariffs_keyboard(),
        parse_mode="HTML"
    )
    await callback.answer()

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())