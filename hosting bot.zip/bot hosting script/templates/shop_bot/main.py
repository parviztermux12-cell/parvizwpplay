import asyncio
import logging
import json
import sqlite3
from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command, CommandObject
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import aiofiles

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Загрузка конфигурации
def load_config():
    try:
        with open('config.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Ошибка загрузки конфига: {e}")
        return {}

config = load_config()
BOT_TOKEN = config.get('bot_token', 'YOUR_BOT_TOKEN_HERE')
ADMIN_IDS = config.get('admin_ids', [])
CURRENCY = config.get('currency', '₽')
REF_REWARD = config.get('ref_reward', 10)  # 10% от покупки реферала

# Инициализация бота
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# Инициализация БД
def init_db():
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    
    # Таблица пользователей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            balance REAL DEFAULT 0,
            ref_id INTEGER,
            reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Таблица товаров
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            quantity INTEGER DEFAULT 0,
            category TEXT,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Таблица покупок
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            product_id INTEGER,
            quantity INTEGER,
            total_price REAL,
            purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id),
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
    ''')
    
    # Таблица рефералов
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS referrals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            referrer_id INTEGER,
            referred_id INTEGER,
            reward REAL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (referrer_id) REFERENCES users (user_id),
            FOREIGN KEY (referred_id) REFERENCES users (user_id)
        )
    ''')
    
    conn.commit()
    conn.close()

init_db()

# Состояния для админ-панели
class AdminStates(StatesGroup):
    waiting_product_name = State()
    waiting_product_description = State()
    waiting_product_price = State()
    waiting_product_quantity = State()
    waiting_product_category = State()

# Клавиатуры
def get_main_keyboard():
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📦 Каталог"), KeyboardButton(text="🏦 Кабинет")],
            [KeyboardButton(text="👥 Партнеры"), KeyboardButton(text="ℹ️ О боте")],
            [KeyboardButton(text="👨‍💻 Админ-панель")]
        ],
        resize_keyboard=True
    )
    return keyboard

def get_admin_keyboard():
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📦 Управление товарами"), KeyboardButton(text="💳 Управление платежами")],
            [KeyboardButton(text="👥 Статистика"), KeyboardButton(text="⚙️ Настройки")],
            [KeyboardButton(text="🔙 Назад")]
        ],
        resize_keyboard=True
    )
    return keyboard

def get_categories_keyboard():
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND is_active = TRUE")
    categories = [row[0] for row in cursor.fetchall()]
    conn.close()
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[])
    
    if categories:
        for category in categories:
            keyboard.inline_keyboard.append([
                InlineKeyboardButton(text=f"📁 {category}", callback_data=f"category_{category}")
            ])
    
    keyboard.inline_keyboard.append([
        InlineKeyboardButton(text="📦 Все товары", callback_data="category_all")
    ])
    
    return keyboard

def get_products_keyboard(category="all", page=0):
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    
    if category == "all":
        cursor.execute("SELECT id, name, price FROM products WHERE is_active = TRUE LIMIT 10 OFFSET ?", (page * 10,))
    else:
        cursor.execute("SELECT id, name, price FROM products WHERE category = ? AND is_active = TRUE LIMIT 10 OFFSET ?", (category, page * 10))
    
    products = cursor.fetchall()
    conn.close()
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[])
    
    for product_id, name, price in products:
        keyboard.inline_keyboard.append([
            InlineKeyboardButton(text=f"{name} - {price}{CURRENCY}", callback_data=f"product_{product_id}")
        ])
    
    # Кнопки навигации
    nav_buttons = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton(text="⬅️ Назад", callback_data=f"page_{category}_{page-1}"))
    
    if len(products) == 10:
        nav_buttons.append(InlineKeyboardButton(text="Вперед ➡️", callback_data=f"page_{category}_{page+1}"))
    
    if nav_buttons:
        keyboard.inline_keyboard.append(nav_buttons)
    
    keyboard.inline_keyboard.append([
        InlineKeyboardButton(text="🔙 Назад к категориям", callback_data="back_to_categories")
    ])
    
    return keyboard

def get_product_keyboard(product_id):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛒 Купить", callback_data=f"buy_{product_id}")],
        [InlineKeyboardButton(text="🔙 Назад к товарам", callback_data="back_to_products")]
    ])
    return keyboard

def get_cabinet_keyboard():
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="replenish_balance")],
        [InlineKeyboardButton(text="📋 История покупок", callback_data="purchase_history")]
    ])
    return keyboard

# Вспомогательные функции
def get_user(user_id):
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    return user

def create_user(user_id, username, first_name, ref_id=None):
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "INSERT OR IGNORE INTO users (user_id, username, first_name, ref_id) VALUES (?, ?, ?, ?)",
            (user_id, username, first_name, ref_id)
        )
        
        # Если есть реферал, начисляем бонус
        if ref_id:
            cursor.execute(
                "INSERT INTO referrals (referrer_id, referred_id) VALUES (?, ?)",
                (ref_id, user_id)
            )
            
        conn.commit()
    except Exception as e:
        logger.error(f"Ошибка создания пользователя: {e}")
    finally:
        conn.close()

def update_balance(user_id, amount):
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))
    conn.commit()
    
    cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
    new_balance = cursor.fetchone()[0]
    conn.close()
    
    return new_balance

def get_products_count():
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM products WHERE is_active = TRUE")
    count = cursor.fetchone()[0]
    conn.close()
    return count

def get_total_sales():
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(total_price) FROM purchases")
    total = cursor.fetchone()[0] or 0
    conn.close()
    return total

def get_users_count():
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM users")
    count = cursor.fetchone()[0]
    conn.close()
    return count

# Обработчики команд
@dp.message(Command("start"))
async def start_command(message: types.Message, command: CommandObject = None):
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name
    
    # Обработка реферальной ссылки
    ref_id = None
    if command and command.args:
        try:
            ref_id = int(command.args)
            if ref_id == user_id:
                ref_id = None  # Нельзя быть своим же рефералом
        except ValueError:
            pass
    
    create_user(user_id, username, first_name, ref_id)
    
    welcome_text = config.get('welcome_text', 
        "👋 Добро пожаловать в наш магазин!\n\n"
        "Здесь вы можете приобрести различные товары и услуги.\n"
        "Используйте кнопки ниже для навигации:"
    )
    
    await message.answer(welcome_text, reply_markup=get_main_keyboard())

@dp.message(Command("admin"))
async def admin_command(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        await message.answer("❌ Доступ запрещен")
        return
    await message.answer("👨‍💻 Админ-панель", reply_markup=get_admin_keyboard())

@dp.message(F.text == "📦 Каталог")
async def catalog_handler(message: types.Message):
    await message.answer(
        "🛒 <b>Каталог товаров</b>\n\n"
        "Выберите категорию:",
        reply_markup=get_categories_keyboard(),
        parse_mode="HTML"
    )

@dp.callback_query(F.data.startswith("category_"))
async def category_handler(callback: types.CallbackQuery):
    category = callback.data.replace("category_", "")
    await callback.message.edit_text(
        f"📦 <b>Товары</b>\n\nВыберите товар:",
        reply_markup=get_products_keyboard(category),
        parse_mode="HTML"
    )
    await callback.answer()

@dp.callback_query(F.data.startswith("page_"))
async def page_handler(callback: types.CallbackQuery):
    data = callback.data.replace("page_", "").split("_")
    category = data[0]
    page = int(data[1])
    
    await callback.message.edit_reply_markup(
        reply_markup=get_products_keyboard(category, page)
    )
    await callback.answer()

@dp.callback_query(F.data.startswith("product_"))
async def product_handler(callback: types.CallbackQuery):
    product_id = int(callback.data.replace("product_", ""))
    
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    cursor.execute("SELECT name, description, price, quantity FROM products WHERE id = ?", (product_id,))
    product = cursor.fetchone()
    conn.close()
    
    if not product:
        await callback.answer("❌ Товар не найден")
        return
    
    name, description, price, quantity = product
    
    product_text = f"""<b>{name}</b>

💵 Цена: <b>{price}{CURRENCY}</b>
📦 В наличии: <b>{quantity} шт.</b>

📝 Описание:
{description or 'Нет описания'}"""
    
    await callback.message.edit_text(
        product_text,
        reply_markup=get_product_keyboard(product_id),
        parse_mode="HTML"
    )
    await callback.answer()

@dp.callback_query(F.data.startswith("buy_"))
async def buy_handler(callback: types.CallbackQuery):
    product_id = int(callback.data.replace("buy_", ""))
    user_id = callback.from_user.id
    
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    
    # Получаем информацию о товаре
    cursor.execute("SELECT name, price, quantity FROM products WHERE id = ?", (product_id,))
    product = cursor.fetchone()
    
    if not product:
        await callback.answer("❌ Товар не найден")
        return
    
    name, price, quantity = product
    
    if quantity <= 0:
        await callback.answer("❌ Товар закончился")
        return
    
    # Проверяем баланс пользователя
    cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
    user_balance = cursor.fetchone()[0]
    
    if user_balance < price:
        await callback.answer("❌ Недостаточно средств")
        return
    
    # Совершаем покупку
    cursor.execute("UPDATE users SET balance = balance - ? WHERE user_id = ?", (price, user_id))
    cursor.execute("UPDATE products SET quantity = quantity - 1 WHERE id = ?", (product_id,))
    cursor.execute("INSERT INTO purchases (user_id, product_id, quantity, total_price) VALUES (?, ?, 1, ?)", 
                  (user_id, product_id, price))
    
    # Начисляем реферальное вознаграждение
    cursor.execute("SELECT ref_id FROM users WHERE user_id = ?", (user_id,))
    ref_result = cursor.fetchone()
    
    if ref_result and ref_result[0]:
        ref_reward = price * (REF_REWARD / 100)
        cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (ref_reward, ref_result[0]))
        cursor.execute("UPDATE referrals SET reward = reward + ? WHERE referred_id = ?", (ref_reward, user_id))
    
    conn.commit()
    conn.close()
    
    await callback.answer(f"✅ Покупка успешна! Спасибо за покупку {name}")
    await callback.message.answer(f"🎉 Вы успешно приобрели <b>{name}</b> за {price}{CURRENCY}", parse_mode="HTML")

@dp.message(F.text == "🏦 Кабинет")
async def cabinet_handler(message: types.Message):
    user_id = message.from_user.id
    user = get_user(user_id)
    
    if not user:
        await message.answer("❌ Пользователь не найден")
        return
    
    user_id, username, first_name, balance, ref_id, reg_date = user
    
    # Получаем статистику рефералов
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*), SUM(reward) FROM referrals WHERE referrer_id = ?", (user_id,))
    ref_stats = cursor.fetchone()
    ref_count = ref_stats[0] or 0
    ref_total = ref_stats[1] or 0
    conn.close()
    
    ref_link = f"https://t.me/{(await bot.get_me()).username}?start={user_id}"
    
    cabinet_text = f"""🏦 <b>Кабинет</b>

🆔 Ваш ID: <code>{user_id}</code>
👤 Имя: {first_name}
💳 Баланс: <b>{balance}{CURRENCY}</b>

👥 <b>Партнерская программа:</b>
👥 Приглашено: {ref_count} человек
💰 Заработано: {ref_total}{CURRENCY}
🔗 Ваша ссылка: <code>{ref_link}</code>

💸 <b>Доступные действия:</b>"""
    
    await message.answer(cabinet_text, reply_markup=get_cabinet_keyboard(), parse_mode="HTML")

@dp.message(F.text == "👥 Партнеры")
async def partners_handler(message: types.Message):
    user_id = message.from_user.id
    ref_link = f"https://t.me/{(await bot.get_me()).username}?start={user_id}"
    
    partners_text = f"""👥 <b>Партнерская программа</b>

🔗 <b>Ваша реферальная ссылка:</b>
<code>{ref_link}</code>

🎁 <b>Как это работает:</b>
• Приводите друзей по вашей ссылке
• Получайте {REF_REWARD}% от их покупок
• Вывод средств доступен от 100{CURRENCY}

📊 <b>Ваша статистика:</b>"""
    
    user = get_user(user_id)
    if user:
        conn = sqlite3.connect('shop.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*), SUM(reward) FROM referrals WHERE referrer_id = ?", (user_id,))
        ref_stats = cursor.fetchone()
        ref_count = ref_stats[0] or 0
        ref_total = ref_stats[1] or 0
        conn.close()
        
        partners_text += f"\n👥 Приглашено: {ref_count} человек"
        partners_text += f"\n💰 Заработано: {ref_total}{CURRENCY}"
    
    await message.answer(partners_text, parse_mode="HTML")

@dp.message(F.text == "ℹ️ О боте")
async def about_handler(message: types.Message):
    products_count = get_products_count()
    total_sales = get_total_sales()
    users_count = get_users_count()
    
    # Вычисляем дни работы (примерно)
    days_working = (datetime.now() - datetime(2024, 1, 1)).days
    
    about_text = f"""📊 <b>О боте</b>

🕜 Работаем: {days_working} дней
👨 Всего пользователей: {users_count}
📦 Товаров в каталоге: {products_count}
💰 Объем продаж: {total_sales}{CURRENCY}
🗃 Куплено товаров: {int(total_sales / 100)} шт.

🤖 <b>Магазин автоматических продаж</b>
💳 Мгновенные покупки
🛡️ Безопасные платежи
👥 Партнерская программа

💬 <b>Поддержка:</b> @support"""
    
    await message.answer(about_text, parse_mode="HTML")

@dp.message(F.text == "👨‍💻 Админ-панель")
async def admin_panel_handler(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        await message.answer("❌ Доступ запрещен")
        return
    await message.answer("👨‍💻 Добро пожаловать в админ-панель!", reply_markup=get_admin_keyboard())

# Админ-обработчики
@dp.message(F.text == "📦 Управление товарами")
async def admin_products_handler(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Добавить товар", callback_data="admin_add_product")],
        [InlineKeyboardButton(text="📋 Список товаров", callback_data="admin_list_products")],
        [InlineKeyboardButton(text="✏️ Редактировать товар", callback_data="admin_edit_products")]
    ])
    
    await message.answer("📦 Управление товарами:", reply_markup=keyboard)

@dp.callback_query(F.data == "admin_add_product")
async def admin_add_product_handler(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    
    await state.set_state(AdminStates.waiting_product_name)
    await callback.message.answer("Введите название товара:")
    await callback.answer()

@dp.message(AdminStates.waiting_product_name)
async def process_product_name(message: types.Message, state: FSMContext):
    await state.update_data(name=message.text)
    await state.set_state(AdminStates.waiting_product_description)
    await message.answer("Введите описание товара:")

@dp.message(AdminStates.waiting_product_description)
async def process_product_description(message: types.Message, state: FSMContext):
    await state.update_data(description=message.text)
    await state.set_state(AdminStates.waiting_product_price)
    await message.answer("Введите цену товара:")

@dp.message(AdminStates.waiting_product_price)
async def process_product_price(message: types.Message, state: FSMContext):
    try:
        price = float(message.text)
        await state.update_data(price=price)
        await state.set_state(AdminStates.waiting_product_quantity)
        await message.answer("Введите количество товара:")
    except ValueError:
        await message.answer("❌ Введите корректную цену (число):")

@dp.message(AdminStates.waiting_product_quantity)
async def process_product_quantity(message: types.Message, state: FSMContext):
    try:
        quantity = int(message.text)
        await state.update_data(quantity=quantity)
        await state.set_state(AdminStates.waiting_product_category)
        await message.answer("Введите категорию товара:")
    except ValueError:
        await message.answer("❌ Введите корректное количество (целое число):")

@dp.message(AdminStates.waiting_product_category)
async def process_product_category(message: types.Message, state: FSMContext):
    data = await state.get_data()
    
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO products (name, description, price, quantity, category) VALUES (?, ?, ?, ?, ?)",
        (data['name'], data['description'], data['price'], data['quantity'], message.text)
    )
    conn.commit()
    conn.close()
    
    await message.answer(f"✅ Товар '{data['name']}' успешно добавлен!")
    await state.clear()

@dp.message(F.text == "👥 Статистика")
async def admin_stats_handler(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    
    products_count = get_products_count()
    total_sales = get_total_sales()
    users_count = get_users_count()
    
    # Получаем сегодняшние продажи
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(total_price) FROM purchases WHERE date(purchase_date) = date('now')")
    today_sales = cursor.fetchone()[0] or 0
    conn.close()
    
    stats_text = f"""📊 <b>Статистика магазина</b>

👥 Пользователей: {users_count}
📦 Товаров: {products_count}
💰 Общие продажи: {total_sales}{CURRENCY}
💰 Продажи за сегодня: {today_sales}{CURRENCY}
👥 Рефералов: {get_users_count() - 1}"""

    await message.answer(stats_text, parse_mode="HTML")

@dp.message(F.text == "🔙 Назад")
async def back_handler(message: types.Message):
    await message.answer("Главное меню:", reply_markup=get_main_keyboard())

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())